.. <Put relevant comments here>

.. <change label name>

.. _demos_<foo_bar>_python_documentation:

.. <change title>

<Foo>
=====

This demo is implemented in a single Python file, :download:`demo.py`,
which contains both the variational forms and the solver.

.. include:: ../common.txt

Implementation
--------------

.. <update the demo name>

This description goes through the implementation (in
:download:`demo.py`) of a solver for <foo> step-by-step.

.. <Add key-words to the index>

.. index:: FunctionSpace, UnitSquare

.. <explain important parts of the code, add links to classes/functions>

We begin by defining a mesh of the domain and a finite element
function space :math:`V` relative to this mesh. As the unit square is
a very standard domain, we can use a built-in mesh provided by the
class :py:class:`UnitSquare`. In order to create a mesh consisting of 32 x 32
squares with each square divided into two triangles, we do as follows

.. <include code snippets (must be exact copies of the source code!)>

.. code-block:: python

    # Create mesh and define function space
    mesh = UnitSquare(32, 32)
    V = FunctionSpace(mesh, "Lagrange", 1)

Complete code
-------------

.. literalinclude:: demo.py
   :start-after: # Begin demo
