.. <Put relevant comments here>

.. <change label name>
.. _demos_<foo_bar>_cpp_documentation:

.. <change title>

<Foo>
=====

.. include:: ../common.txt

Implementation
--------------

.. <update introduction>

The implementation is split in two files: a form file containing the
definition of the variational forms expressed in UFL and a C++ file
containing the actual solver.

.. <update list of files needed to run demo>

Running this demo requires the files: :download:`main.cpp`,
:download:`Poisson.ufl` and :download:`CMakeLists.txt`.

.. <your demo might not need a UFL file>

UFL form file
^^^^^^^^^^^^^

.. <link to form files and explain>

The first step is to define the variational problem at hand. We define
the variational problem in UFL terms in a separate form file
:download:`Poisson.ufl`.  We begin by defining the finite element:

.. <Add key-words to the index>

.. index:: FiniteElement

.. <include code snippets (must be exact copies of the source code!)>

.. code-block:: python

    element = FiniteElement("Lagrange", triangle, 1)

.. <explain important parts of the code, add links to classes/functions>

The first argument to :py:class:`FiniteElement` is the finite element family,
the second argument specifies the domain, while the third argument
specifies the polynomial degree. Thus, in this case, our element
``element`` consists of first-order, continuous Lagrange basis
functions on triangles (or in order words, continuous piecewise linear
polynomials on triangles).

C++ program
^^^^^^^^^^^

The main solver is implemented in the :download:`main.cpp` file.

.. <Add key-words to the index>

.. index:: Expression

.. <explain important parts of the code, add links to classes/functions>

Then follows the definition of the coefficient functions (for :math:`f` and
:math:`g`), which are derived from the :cpp:class:`Expression` class in DOLFIN.

.. <include code snippets (must be exact copies of the source code!)>

.. code-block:: c++

    // Source term (right-hand side)
    class Source : public Expression
    {
      void eval(Array<double>& values, const Array<double>& x) const
      {
        double dx = x[0] - 0.5;
        double dy = x[1] - 0.5;
        values[0] = 10*exp(-(dx*dx + dy*dy) / 0.02);
      }
    };

    // Normal derivative (Neumann boundary condition)
    class dUdN : public Expression
    {
      void eval(Array<double>& values, const Array<double>& x) const
      {
        values[0] = sin(5*x[0]);
      }
    };

Complete code
-------------

Complete UFL file
^^^^^^^^^^^^^^^^^

.. literalinclude:: Poisson.ufl
   :start-after: # Compile this form
   :language: python

Complete main file
^^^^^^^^^^^^^^^^^^

.. literalinclude:: main.cpp
   :start-after: // du/dn
   :language: c++
